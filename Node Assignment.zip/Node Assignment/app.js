// Importing the required modules
const express = require('express'); 
const bodyParser = require('body-parser'); 
const path = require('path'); 
const app = express(); 
const greeting = require('greeting');
const mysql = require('mysql2'); 

// Set up EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views')); 

// Load environment variables from a .env file
require('dotenv').config(); 

// Create a MySQL connection using credentials from .env file
const connection = mysql.createConnection({
    host: process.env.DB_HOST, 
    user: process.env.DB_USER, 
    password: process.env.DB_PASSWORD, 
    database: process.env.DB_NAME 
});

// Connect to MySQL database
connection.connect(err => {
    if (err) {
        console.error('Connecting Error: ' + err.stack); 
        return;
    }
    console.log('Connected to database.'); 
});

// Serve static files (like CSS) from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Use body-parser to handle form data
app.use(bodyParser.urlencoded({ extended: true }));

// Route to display contact page
app.get('/contact', (req, res) => {
    res.render('contact'); 
});

// Route to display homepage with a random greeting
app.get('/homepage', (req, res) => {
    const randomGreeting = greeting.random(); 
    res.render('homepage', { greeting: randomGreeting }); 
});

// Route to display thank you page
app.get('/thankyou', (req, res) => {
    const { firstName, lastName, email } = req.query; 
    res.render('thankyou', { firstName, lastName, email }); 
});

// Route to display about page
app.get('/about', (req, res) => {
    res.render('about'); 
});

// Handle form submissions from contact page
app.post('/submitform', (req, res) => {
    const { firstName, lastName, email, phone, city, province, postalCode, feedback } = req.body; 
    const input = 'INSERT INTO clientinformation (firstName, lastName, email, phone, city, province, postalCode, feedback) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'; // SQL query
    connection.query(input, [firstName, lastName, email, phone, city, province, postalCode, feedback], (err, results) => {
        if (err) {
            res.send('Submit Error: ' + err.message); 
            return;
        }
        res.redirect(`/thankyou?firstName=${encodeURIComponent(firstName)}&lastName=${encodeURIComponent(lastName)}&email=${encodeURIComponent(email)}`); // Redirect to thank you page with name and email
    });
});

// Route to display all entries in the database
app.get('/entries', (req, res) => {
    const input = 'SELECT firstName, lastName, email, feedback FROM clientinformation'; 
    connection.query(input, (err, results) => {
        if (err) {
            res.send('Entry Error: ' + err.message); 
            return;
        }
        res.render('entries', { entries: results }); 
    });
});

// Route to delete an entry from the database
app.delete('/entries/:id', (req, res) => {
    console.log('Delete request for ID:', req.params.id);  // Log received ID
    const input = 'DELETE FROM clientinformation WHERE id = ?';
    connection.query(input, [req.params.id], (err, result) => {
        if (err) {
            console.error('Error occurred:', err);  // Log server error
            res.status(500).send('Error occurred: ' + err.message);
            return;
        }
        res.status(200).send('Entry deleted.');
    });
});


// Middleware to handle 404 errors (page not found)
app.use((req, res, next) => {
    res.status(404).render('404', { url: req.originalUrl });
});

app.listen(8000, () => {
    console.log('Server is running on port 8000');
});
