CREATE DATABASE formdatabase;

USE formdatabase;

CREATE TABLE clientinformation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(30) NOT NULL,
    lastName VARCHAR(30) NOT NULL,
    email VARCHAR(30) NOT NULL,
    phone VARCHAR(10),
    city VARCHAR(30),
    province VARCHAR(30),
    postalCode VARCHAR(7),
    feedback TEXT
);